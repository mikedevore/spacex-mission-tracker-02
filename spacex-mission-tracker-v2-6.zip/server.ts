import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes cache

async function fetchWithCache(url: string) {
  const cached = cache.get(url);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }
  
  console.log(`[Cache Miss] Fetching ${url} from origin`);
  const response = await fetch(url, { headers: { 'User-Agent': 'SpaceXTracker/2.0', 'Accept': 'application/json' } });
  
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  
  const data = await response.json();
  cache.set(url, { data, timestamp: Date.now() });
  return data;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Basic API endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // News Proxy
  app.get("/api/news", async (req, res) => {
    try {
      const source = req.query.source as string;
      if (!source) {
        return res.status(400).json({ error: "Missing source parameter" });
      }
      const data = await fetchWithCache(source);
      res.json(data);
    } catch (e: any) {
      console.error(`Error fetching news: ${e.message}`);
      res.status(500).json({ error: e.message });
    }
  });

  // Generic API Proxy for whitelisted domains (SpaceX, SpaceDevs)
  app.get("/api/proxy", async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) {
        return res.status(400).json({ error: "Missing url parameter" });
      }
      
      const allowedDomains = ["api.spacexdata.com", "lldev.thespacedevs.com", "api.spaceflightnewsapi.net"];
      try {
        const urlObj = new URL(url);
        if (!allowedDomains.includes(urlObj.hostname)) {
          return res.status(403).json({ error: "Domain not allowed" });
        }
      } catch (e) {
        return res.status(400).json({ error: "Invalid URL" });
      }

      const data = await fetchWithCache(url);
      res.json(data);
    } catch (e: any) {
      console.error(`Proxy Error for ${req.query.url}: ${e.message}`);
      res.status(500).json({ error: e.message });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
